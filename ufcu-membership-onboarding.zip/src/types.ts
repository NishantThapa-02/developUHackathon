export type NavCategory = 'Discovery' | 'Identity' | 'Accounts' | 'Finish';

export interface OnboardingState {
  currentStep: number; // 1 to 10
  
  // Step 1: Intent
  intent: 'everyday' | 'saving' | 'credit' | 'auto' | 'home' | 'business' | 'unsure';
  
  // Step 2: Priorities (multi-select)
  priorities: string[]; // e.g. ['fees', 'access', 'paycheck']
  
  // Step 3: Life Stage Persona
  persona: 'student' | 'working_professional' | 'business_owner' | 'retired' | 'other';
  
  // Step 5: Verification Method
  verificationMethod: 'scan' | 'digital' | 'manual';
  
  // Step 6 & 7: User Information
  userInfo: {
    fullName: string;
    dob: string;
    address: string;
    documentId: string;
    issuer: string;
    email: string;
    phone: string;
    ssn: string;
    employmentStatus: 'full-time' | 'self-employed' | 'student' | 'other';
  };
  
  // Step 8: Agreements
  agreements: {
    membership: boolean;
    esign: boolean;
    patriotAct: boolean;
  };
  
  // Step 9: Funding
  funding: {
    amount: number;
    method: 'wallet' | 'plaid' | 'debit' | 'later';
  };
}

export interface StepMetadata {
  number: number;
  label: string;
  category: NavCategory;
  categoryPath: string;
  title: string;
}

export const STEP_METADATA: StepMetadata[] = [
  { number: 1, label: 'Welcome', category: 'Discovery', categoryPath: 'welcome-discovery', title: 'What brings you to UFCU today?' },
  { number: 2, label: 'Priorities', category: 'Discovery', categoryPath: 'welcome-discovery', title: 'Got it. What matters most to you?' },
  { number: 3, label: 'About You', category: 'Discovery', categoryPath: 'welcome-discovery', title: 'Which best describes you right now?' },
  { number: 4, label: 'Recommendation', category: 'Accounts', categoryPath: 'product-selection', title: 'Here’s a good fit based on what you told us.' },
  { number: 5, label: 'Identity Setup', category: 'Identity', categoryPath: 'personal-identity', title: 'Great choice. Let’s get you set up.' },
  { number: 6, label: 'Identity Verification', category: 'Identity', categoryPath: 'personal-identity', title: 'We found your information.' },
  { number: 7, label: 'Final Details', category: 'Identity', categoryPath: 'personal-identity', title: 'Just a few final details.' },
  { number: 8, label: 'Review & Agreements', category: 'Finish', categoryPath: 'verification-finish', title: 'Let’s review your details.' },
  { number: 9, label: 'Fund Account', category: 'Finish', categoryPath: 'verification-finish', title: 'How would you like to fund your new account?' },
  { number: 10, label: 'Complete', category: 'Finish', categoryPath: 'verification-finish', title: 'Welcome to UFCU, Elena.' }
];

export const INITIAL_ONBOARDING_STATE: OnboardingState = {
  currentStep: 1,
  intent: 'everyday',
  priorities: ['fees', 'access', 'paycheck'],
  persona: 'working_professional',
  verificationMethod: 'scan',
  userInfo: {
    fullName: 'Elena Christine Rodriguez',
    dob: 'October 14, 1992',
    address: '2401 Rio Grande St, Apt 4B, Austin, TX 78705',
    documentId: 'TX DL •••• 9842',
    issuer: 'Texas DPS',
    email: 'elena.rodriguez@domain.com',
    phone: '(512) 555-0198',
    ssn: '987654821',
    employmentStatus: 'full-time'
  },
  agreements: {
    membership: true,
    esign: true,
    patriotAct: true
  },
  funding: {
    amount: 50,
    method: 'wallet'
  }
};
