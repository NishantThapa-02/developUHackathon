import React, { useState } from 'react';
import { OnboardingState, INITIAL_ONBOARDING_STATE } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HelpModal } from './components/HelpModal';
import { Step1Welcome } from './components/steps/Step1Welcome';
import { Step2Priorities } from './components/steps/Step2Priorities';
import { Step3AboutYou } from './components/steps/Step3AboutYou';
import { Step4Recommendation } from './components/steps/Step4Recommendation';
import { Step5IdentitySetup } from './components/steps/Step5IdentitySetup';
import { Step6IdentityVerification } from './components/steps/Step6IdentityVerification';
import { Step7FinalDetails } from './components/steps/Step7FinalDetails';
import { Step8ReviewAgreements } from './components/steps/Step8ReviewAgreements';
import { Step9Funding } from './components/steps/Step9Funding';
import { Step10Complete } from './components/steps/Step10Complete';

export default function App() {
  const [state, setState] = useState<OnboardingState>(INITIAL_ONBOARDING_STATE);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const handleUpdateState = (updates: Partial<OnboardingState>) => {
    setState((prev) => ({ ...prev, ...updates }));
  };

  const handleSelectStep = (step: number) => {
    if (step >= 1 && step <= 10) {
      setState((prev) => ({ ...prev, currentStep: step }));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleNext = () => {
    if (state.currentStep < 10) {
      setState((prev) => ({ ...prev, currentStep: prev.currentStep + 1 }));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    if (state.currentStep > 1) {
      setState((prev) => ({ ...prev, currentStep: prev.currentStep - 1 }));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleReset = () => {
    setState(INITIAL_ONBOARDING_STATE);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f7f9fb] text-[#191c1e] font-sans">
      {/* Top Fixed Header with Category Navigation & Progress */}
      <Header
        currentStep={state.currentStep}
        onSelectStep={handleSelectStep}
        onOpenHelp={() => setIsHelpOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 md:px-6 pt-28 pb-14 flex flex-col justify-center">
        {state.currentStep === 1 && (
          <Step1Welcome
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
          />
        )}

        {state.currentStep === 2 && (
          <Step2Priorities
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 3 && (
          <Step3AboutYou
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
            onOpenHelp={() => setIsHelpOpen(true)}
          />
        )}

        {state.currentStep === 4 && (
          <Step4Recommendation
            state={state}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 5 && (
          <Step5IdentitySetup
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 6 && (
          <Step6IdentityVerification
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 7 && (
          <Step7FinalDetails
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 8 && (
          <Step8ReviewAgreements
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
            onEditPersonalInfo={() => handleSelectStep(6)}
          />
        )}

        {state.currentStep === 9 && (
          <Step9Funding
            state={state}
            onUpdate={handleUpdateState}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {state.currentStep === 10 && (
          <Step10Complete
            state={state}
            onReset={handleReset}
          />
        )}
      </main>

      {/* Standard NCUA & Legal Footer */}
      <Footer />

      {/* Member Help & Central Texas Advisory Modal */}
      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />
    </div>
  );
}
