import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step6Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Step6IdentityVerification: React.FC<Step6Props> = ({ state, onUpdate, onNext, onPrev }) => {
  const [editingField, setEditingField] = useState<string | null>(null);
  const [tempValues, setTempValues] = useState({
    fullName: state.userInfo.fullName,
    dob: state.userInfo.dob,
    address: state.userInfo.address
  });

  const handleSaveField = (field: 'fullName' | 'dob' | 'address') => {
    onUpdate({
      userInfo: {
        ...state.userInfo,
        [field]: tempValues[field]
      }
    });
    setEditingField(null);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-2xl mx-auto animate-fadeIn">
      {/* Step Header Meta */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase tracking-wider text-[#a33e00] font-semibold">
            Step 6 of 10 • Identity Verification
          </span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#eceef0] text-[#0b1d47] text-xs font-medium">
            <span className="material-symbols-outlined text-[15px] text-[#fc712a]">verified_user</span>
            Encrypted Session
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          We found your information.
        </h1>
        <p className="text-sm sm:text-base text-[#45464f]">
          We’ll reuse verified information so you don’t have to enter it again.
        </p>
      </div>

      {/* Scanner Progress Tracker Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full p-2 bg-[#f2f4f6] rounded-xl border border-slate-200/50">
        <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white shadow-2xs text-[#0b1d47]">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">check_circle</span>
          <span className="text-xs font-semibold truncate">1. Position ID</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white shadow-2xs text-[#0b1d47]">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">check_circle</span>
          <span className="text-xs font-semibold truncate">2. Scanning</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white shadow-2xs text-[#0b1d47]">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">check_circle</span>
          <span className="text-xs font-semibold truncate">3. Verifying</span>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#23335d] text-white shadow-xs">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">task_alt</span>
          <span className="text-xs font-semibold truncate">4. Verified</span>
        </div>
      </div>

      {/* Hero Credential Card Graphic */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#23335d] via-[#0b1d47] to-[#191c1e] p-5 sm:p-6 text-white shadow-xl border border-slate-800">
        {/* Decorative Watermark */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 pointer-events-none flex items-center justify-center">
          <span className="material-symbols-outlined text-[240px]">shield</span>
        </div>

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-xs border border-white/10">
              <span className="material-symbols-outlined text-[28px] text-[#ffdbcd]">badge</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base sm:text-lg tracking-tight font-['Plus_Jakarta_Sans']">
                  Texas Driver License
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#fc712a] text-white text-[10px] font-bold">
                  <span className="material-symbols-outlined text-[13px]">verified</span>
                  Verified
                </span>
              </div>
              <p className="text-xs text-[#8d9ccd]">State of Texas Credential • Real ID Compliant</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-md border border-white/10 text-[11px] font-mono tracking-wider">
            <span className="material-symbols-outlined text-[16px] text-[#ffdbcb]">lock_clock</span>
            <span>SECURE-PARSE • 99.8%</span>
          </div>
        </div>

        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-14 h-16 rounded-lg bg-white/20 overflow-hidden relative flex items-center justify-center shrink-0 border border-white/20">
              <img
                alt="ID Photo portrait silhouette"
                className="w-full h-full object-cover"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuD3HpnESyGt7tt0uUVkqzTPvHNt8UOGtL6KYP_gogT3m9DaSD4urgcIcV5xC9HXxeiKv532DmoC6pxVgZL0ESP2vuon-4T-2tZKwuPTtDsqxi14vah9ovgkXRU58SD3fPAnw6eBFGFN9yLea1XA5tgUM3bnXIQumzNIEI2IazLZV4cnVLB_ikOLRNZIuVtDwdRKKXx_Y9tQm3TONomnKNmqIE2PBH8ctmBxj8hDQse7E26V9v5_BP6m"
              />
              <div className="absolute bottom-0 inset-x-0 bg-[#0b1d47]/80 backdrop-blur-2xs text-center py-0.5">
                <span className="text-[8px] text-white uppercase font-bold tracking-wider">Photo ID</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-[#8d9ccd] uppercase tracking-wider text-[10px]">Issuer</span>
              <span className="text-sm font-semibold text-white">Texas DPS</span>
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <span className="text-[#8d9ccd] uppercase tracking-wider text-[10px]">Document ID</span>
            <span className="text-sm text-white font-mono tracking-widest font-semibold">{state.userInfo.documentId}</span>
          </div>

          <div className="flex flex-col justify-center sm:items-end">
            <span className="text-[#8d9ccd] uppercase tracking-wider text-[10px]">Authenticity Status</span>
            <span className="inline-flex items-center gap-1 text-[#ffdbcb] font-semibold text-xs mt-0.5">
              <span className="material-symbols-outlined text-[16px] text-[#fc712a]">check_circle</span>
              Hologram Verified
            </span>
          </div>
        </div>
      </div>

      {/* Extracted Member Information */}
      <div className="bg-white rounded-2xl shadow-md p-5 sm:p-6 flex flex-col gap-3.5 border border-slate-100">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#23335d] text-[20px]">assignment_turned_in</span>
            <h2 className="text-base font-bold text-[#0b1d47] font-['Plus_Jakarta_Sans']">
              Extracted Member Information
            </h2>
          </div>
          <span className="text-[#45464f] text-xs">Auto-populated</span>
        </div>

        {/* Field 1: Full Name */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-[#f2f4f6] hover:bg-[#eceef0] transition-colors gap-3">
          <div className="flex flex-col flex-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider font-semibold">Full Legal Name</span>
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-white text-[#a33e00] text-[10px] font-semibold shadow-2xs">
                <span className="material-symbols-outlined text-[12px]">check</span> Verified via ID
              </span>
            </div>
            {editingField === 'fullName' ? (
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  value={tempValues.fullName}
                  onChange={(e) => setTempValues({ ...tempValues, fullName: e.target.value })}
                  className="p-1.5 bg-white rounded-lg text-sm text-[#0b1d47] font-semibold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#fc712a] flex-1"
                />
                <button
                  onClick={() => handleSaveField('fullName')}
                  className="px-3 py-1 bg-[#fc712a] text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Save
                </button>
              </div>
            ) : (
              <span className="text-base font-bold text-[#0b1d47] mt-0.5">
                {state.userInfo.fullName}
              </span>
            )}
          </div>
          {editingField !== 'fullName' && (
            <button
              type="button"
              onClick={() => setEditingField('fullName')}
              className="self-start sm:self-center inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[#23335d] hover:bg-slate-200 transition-colors text-xs font-semibold cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">edit</span>
              <span>Edit</span>
            </button>
          )}
        </div>

        {/* Field 2: Date of Birth */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-[#f2f4f6] hover:bg-[#eceef0] transition-colors gap-3">
          <div className="flex flex-col flex-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider font-semibold">Date of Birth</span>
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-white text-[#a33e00] text-[10px] font-semibold shadow-2xs">
                <span className="material-symbols-outlined text-[12px]">check</span> Verified via ID
              </span>
            </div>
            {editingField === 'dob' ? (
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  value={tempValues.dob}
                  onChange={(e) => setTempValues({ ...tempValues, dob: e.target.value })}
                  className="p-1.5 bg-white rounded-lg text-sm text-[#0b1d47] font-semibold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#fc712a] flex-1"
                />
                <button
                  onClick={() => handleSaveField('dob')}
                  className="px-3 py-1 bg-[#fc712a] text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Save
                </button>
              </div>
            ) : (
              <span className="text-base font-bold text-[#0b1d47] mt-0.5">
                {state.userInfo.dob}
              </span>
            )}
          </div>
          {editingField !== 'dob' && (
            <button
              type="button"
              onClick={() => setEditingField('dob')}
              className="self-start sm:self-center inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[#23335d] hover:bg-slate-200 transition-colors text-xs font-semibold cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">edit</span>
              <span>Edit</span>
            </button>
          )}
        </div>

        {/* Field 3: Residential Address */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-[#f2f4f6] hover:bg-[#eceef0] transition-colors gap-3">
          <div className="flex flex-col flex-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider font-semibold">Residential Address</span>
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-white text-[#a33e00] text-[10px] font-semibold shadow-2xs">
                <span className="material-symbols-outlined text-[12px]">check</span> Verified via ID
              </span>
            </div>
            {editingField === 'address' ? (
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="text"
                  value={tempValues.address}
                  onChange={(e) => setTempValues({ ...tempValues, address: e.target.value })}
                  className="p-1.5 bg-white rounded-lg text-sm text-[#0b1d47] font-semibold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#fc712a] flex-1"
                />
                <button
                  onClick={() => handleSaveField('address')}
                  className="px-3 py-1 bg-[#fc712a] text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Save
                </button>
              </div>
            ) : (
              <span className="text-sm sm:text-base font-semibold text-[#0b1d47] mt-0.5">
                {state.userInfo.address}
              </span>
            )}
          </div>
          {editingField !== 'address' && (
            <button
              type="button"
              onClick={() => setEditingField('address')}
              className="self-start sm:self-center inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[#23335d] hover:bg-slate-200 transition-colors text-xs font-semibold cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">edit</span>
              <span>Edit</span>
            </button>
          )}
        </div>

        {/* Field 4: Document Identifier (Read Only) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-[#f2f4f6] gap-3">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider font-semibold">Document ID Number</span>
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-white text-[#a33e00] text-[10px] font-semibold shadow-2xs">
                <span className="material-symbols-outlined text-[12px]">lock</span> Encrypted Match
              </span>
            </div>
            <span className="text-sm sm:text-base text-[#0b1d47] font-mono font-bold mt-0.5">
              {state.userInfo.documentId}
            </span>
          </div>
          <div className="self-start sm:self-center">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-[#45464f] text-xs bg-[#e6e8ea]">
              <span className="material-symbols-outlined text-[14px]">shield</span> Immutable
            </span>
          </div>
        </div>
      </div>

      {/* Reassurance Callout Note */}
      <div className="flex items-start gap-3 p-4 rounded-xl bg-[#f2f4f6] text-[#45464f] border border-slate-200/50">
        <span className="material-symbols-outlined text-[#fc712a] text-[22px] shrink-0 mt-0.5">info</span>
        <p className="text-xs leading-relaxed">
          All extracted information is accurate from your official government credential. Notice anything off? You can tap <strong className="text-[#0b1d47] font-semibold">Edit</strong> to adjust.
        </p>
      </div>

      {/* Bottom Actions */}
      <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
        <button
          onClick={onPrev}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>
        <button
          onClick={onNext}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl bg-[#fc712a] hover:bg-[#e05a12] text-white shadow-md hover:shadow-lg font-bold text-xs sm:text-sm transition-all active:scale-[0.98] cursor-pointer"
        >
          <span>Confirm & Continue</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};
