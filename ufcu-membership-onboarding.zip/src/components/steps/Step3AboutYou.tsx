import React from 'react';
import { OnboardingState } from '../../types';

interface Step3Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
  onOpenHelp: () => void;
}

export const Step3AboutYou: React.FC<Step3Props> = ({ state, onUpdate, onNext, onPrev, onOpenHelp }) => {
  const personas = [
    {
      id: 'student' as const,
      icon: 'school',
      title: 'Student',
      badge: 'Special fee waivers & student perks',
      desc: 'Enrolled in college, university, or trade school'
    },
    {
      id: 'working_professional' as const,
      icon: 'badge',
      title: 'Working professional',
      badge: 'Early direct deposit & rewards',
      desc: 'Employed or self-employed looking for everyday financial convenience'
    },
    {
      id: 'business_owner' as const,
      icon: 'storefront',
      title: 'Business owner',
      badge: null,
      desc: 'Sole proprietor, LLC, or enterprise operator'
    },
    {
      id: 'retired' as const,
      icon: 'nature_people',
      title: 'Retired',
      badge: null,
      desc: 'Enjoying retirement and managing wealth/fixed income'
    },
    {
      id: 'other' as const,
      icon: 'explore',
      title: 'Something else',
      badge: null,
      desc: 'Taking a break, transitioning, or other life stages'
    }
  ];

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col gap-6 animate-fadeIn">
      {/* Context Progress & Session Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full bg-[#e6e8ea] text-[#23335d] text-xs uppercase tracking-wider font-semibold">
            Step 3 of 10
          </span>
          <span className="text-slate-400 text-xs">•</span>
          <span className="text-xs font-medium text-[#45464f]">About You</span>
        </div>
        <div className="flex items-center gap-1.5 text-[#45464f] text-xs">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">shield</span>
          <span>Secure Personalized Match</span>
        </div>
      </div>

      {/* Conversational Heading Block */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          Which best describes you right now?
        </h1>
        <p className="text-sm sm:text-base text-[#45464f]">
          This helps UFCU unlock community discounts, student perks, or commercial privileges.
        </p>
      </div>

      {/* Option Cards Stack */}
      <fieldset aria-label="Current occupational or life stage status" className="flex flex-col gap-3">
        <legend className="sr-only">Choose your current status to personalize your credit union benefits</legend>
        {personas.map((item) => {
          const isSelected = state.persona === item.id;
          return (
            <label
              key={item.id}
              onClick={() => onUpdate({ persona: item.id })}
              className={`group relative flex items-start justify-between gap-4 p-4 rounded-xl cursor-pointer text-left transition-all duration-200 select-none ${
                isSelected
                  ? 'bg-[#ffdbcb]/40 shadow-md ring-2 ring-[#fc712a]'
                  : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
              }`}
            >
              <input
                type="radio"
                name="member_persona"
                value={item.id}
                checked={isSelected}
                onChange={() => onUpdate({ persona: item.id })}
                className="sr-only"
              />
              <div className="flex items-start gap-3.5 min-w-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                  isSelected ? 'bg-[#fc712a] text-white shadow-xs' : 'bg-[#eceef0] text-[#0b1d47] group-hover:bg-[#dae1ff]'
                }`}>
                  <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                </div>
                <div className="flex flex-col gap-0.5 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-sm sm:text-base font-semibold ${
                      isSelected ? 'text-[#360f00] font-bold' : 'text-[#0b1d47]'
                    }`}>
                      {item.title}
                    </span>
                    {item.badge && (
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        isSelected ? 'bg-white text-[#a33e00] font-semibold shadow-2xs' : 'bg-[#f2f4f6] text-[#23335d]'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <p className={`text-xs ${
                    isSelected ? 'text-[#7c2e00]' : 'text-[#45464f]'
                  }`}>
                    {item.desc}
                  </p>
                </div>
              </div>
              <div className={`w-6 h-6 rounded-full shrink-0 flex items-center justify-center mt-1 transition-all ${
                isSelected ? 'bg-[#fc712a] text-white shadow-xs' : 'bg-[#eceef0] text-transparent'
              }`}>
                <span className="material-symbols-outlined text-[16px] font-bold">check</span>
              </div>
            </label>
          );
        })}
      </fieldset>

      {/* Context Highlight Banner with Photo Accent */}
      <div className="relative overflow-hidden rounded-xl bg-white border border-slate-100 p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs">
        <div className="flex items-center gap-3.5 min-w-0">
          <img
            alt="Central Texas young professional portrait"
            className="w-12 h-12 rounded-full object-cover shrink-0 shadow-xs border border-orange-100"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBICN0-SMcwVOaMlJtkuXWDrJWxzqEMkjg7JPlqK3TH8_C1j8tNL0bqBNL3Il-Ps04pF2gDrk9yOPXxQPNPm5HAw6dIRIJvWBkk3b0YQrNdNcM5gLSZBhoNkcmPCmfdzekJHc-H_j8wZfcLpTyn5ZGrZBi5P9TRB_ZxerfMEnzJTnO30EU6kjBGYn8yiIIwTrfYbU6-B7eZPNIlFrH9DVqJP4VADjY8J2PqBcbvIPPu8f7wvQ1PZE-Z"
          />
          <div className="flex flex-col min-w-0">
            <span className="text-xs font-semibold text-[#0b1d47]">Why this matters</span>
            <p className="text-xs text-[#45464f]">
              We tailor account fee structures and matching loan rates based on your community affiliation.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onOpenHelp}
          className="flex items-center gap-1 text-[#a33e00] hover:text-[#fc712a] text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer"
        >
          <span>Eligibility details</span>
          <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
        </button>
      </div>

      {/* Action Bar Tray */}
      <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <button
          onClick={onPrev}
          type="button"
          className="h-12 px-5 rounded-xl bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>
        <button
          onClick={onNext}
          type="button"
          className="h-12 px-6 rounded-xl bg-[#fc712a] hover:bg-[#e05a12] text-white text-xs font-bold shadow-md hover:shadow-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          <span>See My Recommendation</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>

      {/* Micro-trust Statement */}
      <div className="flex items-start justify-center gap-1.5 text-center px-2">
        <span className="material-symbols-outlined text-[16px] text-[#23335d] shrink-0 mt-0.5">verified_user</span>
        <p className="text-xs text-[#45464f] max-w-xl">
          UFCU is open to anyone who lives, works, worships, or attends school in Central Texas & Galveston County.
        </p>
      </div>
    </div>
  );
};
