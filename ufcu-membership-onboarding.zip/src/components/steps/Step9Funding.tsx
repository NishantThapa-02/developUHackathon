import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step9Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Step9Funding: React.FC<Step9Props> = ({ state, onUpdate, onNext, onPrev }) => {
  const [customAmount, setCustomAmount] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const presetAmounts = [25, 50, 100, 250];

  const handleSelectAmount = (amt: number) => {
    onUpdate({
      funding: {
        ...state.funding,
        amount: amt
      }
    });
    setCustomAmount('');
  };

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^0-9]/g, '');
    setCustomAmount(val);
    if (val) {
      onUpdate({
        funding: {
          ...state.funding,
          amount: parseInt(val, 10)
        }
      });
    }
  };

  const handleMethodSelect = (method: 'wallet' | 'plaid' | 'debit' | 'later') => {
    onUpdate({
      funding: {
        ...state.funding,
        method
      }
    });
  };

  const handleSubmit = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onNext();
    }, 800);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#a33e00] font-semibold">
            Step 9 of 10 • Fund Account
          </span>
          <span className="text-slate-300 text-xs">•</span>
          <span className="text-[#45464f] text-xs">Initial Deposit</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          How would you like to fund your new account?
        </h1>
        <p className="text-sm sm:text-base text-[#45464f]">
          Add your initial opening balance. UFCU covers your $5 membership share, so any amount you add is 100% yours to spend or save.
        </p>
      </div>

      {/* Main Funding Card */}
      <div className="bg-white rounded-2xl shadow-md p-5 sm:p-7 flex flex-col gap-6 border border-slate-100">
        {/* Section 1: Choose Opening Amount */}
        <div className="flex flex-col gap-3">
          <label className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Select Opening Amount
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {presetAmounts.map((amt) => {
              const isSelected = state.funding.amount === amt && !customAmount;
              return (
                <button
                  key={amt}
                  type="button"
                  onClick={() => handleSelectAmount(amt)}
                  className={`py-3 px-2 rounded-xl text-center font-bold text-sm sm:text-base transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#fc712a] text-white shadow-sm ring-2 ring-[#fc712a]'
                      : 'bg-[#f2f4f6] text-[#0b1d47] hover:bg-[#eceef0]'
                  }`}
                >
                  ${amt}
                </button>
              );
            })}
          </div>

          <div className="relative flex items-center mt-1">
            <span className="absolute left-3.5 text-sm font-bold text-[#45464f]">$</span>
            <input
              type="text"
              placeholder="Or enter custom amount (e.g. 500)"
              value={customAmount}
              onChange={handleCustomAmountChange}
              className="w-full h-11 pl-8 pr-4 rounded-xl bg-[#f2f4f6] text-xs sm:text-sm text-[#0b1d47] border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#fc712a] transition-all font-semibold"
            />
          </div>
        </div>

        {/* Section 2: Choose Payment Method */}
        <div className="flex flex-col gap-3">
          <label className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Funding Method
          </label>

          <div className="flex flex-col gap-2.5">
            {/* Wallet */}
            <div
              onClick={() => handleMethodSelect('wallet')}
              className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                state.funding.method === 'wallet'
                  ? 'bg-[#ffdbcb]/30 ring-2 ring-[#fc712a] shadow-xs'
                  : 'bg-[#f2f4f6] hover:bg-[#eceef0]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#0b1d47] text-white flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[20px]">contactless</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs sm:text-sm text-[#0b1d47]">Apple Pay / Google Pay</span>
                    <span className="px-1.5 py-0.5 rounded bg-[#fc712a] text-white text-[9px] font-bold">INSTANT</span>
                  </div>
                  <span className="text-[11px] text-[#45464f]">Fastest, fee-free transfer using biometrics</span>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                state.funding.method === 'wallet' ? 'bg-[#fc712a] text-white' : 'bg-[#e6e8ea]'
              }`}>
                {state.funding.method === 'wallet' && (
                  <span className="material-symbols-outlined text-[14px]">check</span>
                )}
              </div>
            </div>

            {/* Plaid / Bank Transfer */}
            <div
              onClick={() => handleMethodSelect('plaid')}
              className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                state.funding.method === 'plaid'
                  ? 'bg-[#ffdbcb]/30 ring-2 ring-[#fc712a] shadow-xs'
                  : 'bg-[#f2f4f6] hover:bg-[#eceef0]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#23335d] text-white flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[20px]">account_balance</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs sm:text-sm text-[#0b1d47]">Connect Existing Bank Account</span>
                    <span className="px-1.5 py-0.5 rounded bg-[#dae1ff] text-[#061942] text-[9px] font-semibold">POPULAR</span>
                  </div>
                  <span className="text-[11px] text-[#45464f]">Link Chase, BoA, Wells Fargo, or any bank securely</span>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                state.funding.method === 'plaid' ? 'bg-[#fc712a] text-white' : 'bg-[#e6e8ea]'
              }`}>
                {state.funding.method === 'plaid' && (
                  <span className="material-symbols-outlined text-[14px]">check</span>
                )}
              </div>
            </div>

            {/* Debit Card */}
            <div
              onClick={() => handleMethodSelect('debit')}
              className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                state.funding.method === 'debit'
                  ? 'bg-[#ffdbcb]/30 ring-2 ring-[#fc712a] shadow-xs'
                  : 'bg-[#f2f4f6] hover:bg-[#eceef0]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#e6e8ea] text-[#0b1d47] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[20px]">credit_card</span>
                </div>
                <div>
                  <span className="font-bold text-xs sm:text-sm text-[#0b1d47] block">Debit Card</span>
                  <span className="text-[11px] text-[#45464f]">Instant deposit via Visa or Mastercard debit</span>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                state.funding.method === 'debit' ? 'bg-[#fc712a] text-white' : 'bg-[#e6e8ea]'
              }`}>
                {state.funding.method === 'debit' && (
                  <span className="material-symbols-outlined text-[14px]">check</span>
                )}
              </div>
            </div>

            {/* Fund Later */}
            <div
              onClick={() => handleMethodSelect('later')}
              className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all ${
                state.funding.method === 'later'
                  ? 'bg-[#ffdbcb]/30 ring-2 ring-[#fc712a] shadow-xs'
                  : 'bg-[#f2f4f6] hover:bg-[#eceef0]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#e6e8ea] text-[#45464f] flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-[20px]">schedule</span>
                </div>
                <div>
                  <span className="font-bold text-xs sm:text-sm text-[#0b1d47] block">I’ll fund later</span>
                  <span className="text-[11px] text-[#45464f]">Complete setup now and add funds within 30 days</span>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                state.funding.method === 'later' ? 'bg-[#fc712a] text-white' : 'bg-[#e6e8ea]'
              }`}>
                {state.funding.method === 'later' && (
                  <span className="material-symbols-outlined text-[14px]">check</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="flex items-center gap-2 p-3 bg-white rounded-xl border border-slate-100 text-xs text-[#45464f]">
        <span className="material-symbols-outlined text-[#fc712a] text-[18px]">verified_user</span>
        <span>
          Deposits are federally insured by NCUA up to $250,000. UFCU never charges fees for incoming deposits.
        </span>
      </div>

      {/* Navigation Buttons */}
      <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
        <button
          onClick={onPrev}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>
        <button
          onClick={handleSubmit}
          disabled={isProcessing}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-[#fc712a] hover:bg-[#e05a12] text-white shadow-md hover:shadow-lg font-bold text-xs sm:text-sm transition-all active:scale-[0.98] cursor-pointer"
        >
          {isProcessing ? (
            <>
              <span className="material-symbols-outlined animate-spin text-[18px]">progress_activity</span>
              <span>Finalizing membership...</span>
            </>
          ) : (
            <>
              <span>
                {state.funding.method === 'later'
                  ? 'Complete Membership Setup'
                  : `Deposit $${state.funding.amount} & Open Account`}
              </span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
