import React from 'react';
import { OnboardingState } from '../../types';

interface Step8Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
  onEditPersonalInfo: () => void;
}

export const Step8ReviewAgreements: React.FC<Step8Props> = ({
  state,
  onUpdate,
  onNext,
  onPrev,
  onEditPersonalInfo
}) => {
  const toggleAgreement = (key: keyof OnboardingState['agreements']) => {
    onUpdate({
      agreements: {
        ...state.agreements,
        [key]: !state.agreements[key]
      }
    });
  };

  const allAgreed = state.agreements.membership && state.agreements.esign && state.agreements.patriotAct;

  return (
    <div className="flex flex-col gap-6 w-full max-w-2xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#a33e00] font-semibold">
            Step 8 of 10 • Review & Agreements
          </span>
          <span className="text-slate-300 text-xs">•</span>
          <span className="text-[#45464f] text-xs">Final Confirmation</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          Let’s review your details.
        </h1>
        <p className="text-sm sm:text-base text-[#45464f]">
          Take a moment to confirm everything looks right before we establish your UFCU membership.
        </p>
      </div>

      {/* Bento Review Card */}
      <div className="bg-white rounded-2xl shadow-md p-5 sm:p-6 flex flex-col gap-5 border border-slate-100">
        {/* Account Summary */}
        <div className="p-4 rounded-xl bg-[#ffdbcb]/20 border border-[#ffb691]/40 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-[#a33e00] uppercase tracking-wider">
              Selected Account Package
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#fc712a] text-white text-[10px] font-bold">
              $0 / Month
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#0b1d47] text-white flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[22px]">account_balance</span>
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-[#0b1d47]">
                UFCU Free Checking + High-Yield Member Savings
              </h3>
              <p className="text-xs text-[#45464f]">
                Includes 4.25% APY yield vault, free debit card, and 55,000+ ATMs nationwide.
              </p>
            </div>
          </div>
        </div>

        {/* Member Personal Details */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#fc712a]">person</span>
              Member Identity Summary
            </h4>
            <button
              type="button"
              onClick={onEditPersonalInfo}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#23335d] hover:text-[#fc712a] transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">edit</span>
              <span>Edit Details</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider">Legal Name</span>
              <span className="font-bold text-sm text-[#0b1d47] mt-0.5">{state.userInfo.fullName}</span>
            </div>

            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider">Date of Birth</span>
              <span className="font-bold text-sm text-[#0b1d47] mt-0.5">{state.userInfo.dob}</span>
            </div>

            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col sm:col-span-2">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider">Residential Address</span>
              <span className="font-semibold text-xs text-[#0b1d47] mt-0.5">{state.userInfo.address}</span>
            </div>

            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider">Email</span>
              <span className="font-semibold text-xs text-[#0b1d47] mt-0.5">{state.userInfo.email}</span>
            </div>

            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col">
              <span className="text-[10px] text-[#45464f] uppercase tracking-wider">Phone</span>
              <span className="font-semibold text-xs text-[#0b1d47] mt-0.5">{state.userInfo.phone}</span>
            </div>

            <div className="p-3 bg-[#f2f4f6] rounded-lg flex flex-col sm:col-span-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#45464f] uppercase tracking-wider">SSN / ITIN</span>
                <span className="text-[10px] text-[#23335d] font-semibold flex items-center gap-1">
                  <span className="material-symbols-outlined text-[13px] text-green-600">lock</span> Verified
                </span>
              </div>
              <span className="font-mono font-bold text-xs text-[#0b1d47] mt-0.5">
                •••-••-{state.userInfo.ssn.slice(-4) || '4821'}
              </span>
            </div>
          </div>
        </div>

        {/* Regulatory & Member Consents */}
        <div className="pt-2 flex flex-col gap-3">
          <h4 className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#fc712a]">gavel</span>
            Agreements & Consents
          </h4>

          {/* Agreement 1 */}
          <label 
            onClick={() => toggleAgreement('membership')}
            className="flex items-start gap-3 p-3 rounded-xl bg-[#f2f4f6] hover:bg-slate-100 transition-colors cursor-pointer select-none"
          >
            <input
              type="checkbox"
              checked={state.agreements.membership}
              onChange={() => {}}
              className="mt-1 w-4 h-4 rounded text-[#fc712a] focus:ring-[#fc712a] accent-[#fc712a] cursor-pointer"
            />
            <div className="text-xs text-[#191c1e] leading-relaxed">
              <span className="font-semibold text-[#0b1d47]">Membership Agreement & Credit Union Bylaws:</span> I agree to UFCU’s account terms, membership qualifications, and schedule of fees. UFCU covers your $5 cooperative share deposit upon opening.
            </div>
          </label>

          {/* Agreement 2 */}
          <label 
            onClick={() => toggleAgreement('esign')}
            className="flex items-start gap-3 p-3 rounded-xl bg-[#f2f4f6] hover:bg-slate-100 transition-colors cursor-pointer select-none"
          >
            <input
              type="checkbox"
              checked={state.agreements.esign}
              onChange={() => {}}
              className="mt-1 w-4 h-4 rounded text-[#fc712a] focus:ring-[#fc712a] accent-[#fc712a] cursor-pointer"
            />
            <div className="text-xs text-[#191c1e] leading-relaxed">
              <span className="font-semibold text-[#0b1d47]">E-SIGN Consent:</span> I consent to receive electronic disclosures, notices, account updates, and tax forms electronically.
            </div>
          </label>

          {/* Agreement 3 */}
          <label 
            onClick={() => toggleAgreement('patriotAct')}
            className="flex items-start gap-3 p-3 rounded-xl bg-[#f2f4f6] hover:bg-slate-100 transition-colors cursor-pointer select-none"
          >
            <input
              type="checkbox"
              checked={state.agreements.patriotAct}
              onChange={() => {}}
              className="mt-1 w-4 h-4 rounded text-[#fc712a] focus:ring-[#fc712a] accent-[#fc712a] cursor-pointer"
            />
            <div className="text-xs text-[#191c1e] leading-relaxed">
              <span className="font-semibold text-[#0b1d47]">Taxpayer Certification:</span> Under penalties of perjury, I certify that the Taxpayer Identification Number provided is correct and that I am a U.S. citizen or other U.S. person.
            </div>
          </label>
        </div>
      </div>

      {/* Actions */}
      <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
        <button
          onClick={onPrev}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>
        <button
          onClick={onNext}
          disabled={!allAgreed}
          type="button"
          className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-[0.98] cursor-pointer ${
            allAgreed
              ? 'bg-[#fc712a] hover:bg-[#e05a12] hover:shadow-lg'
              : 'bg-slate-300 opacity-60 cursor-not-allowed'
          }`}
        >
          <span>I Agree & Submit Application</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>

      <div className="flex items-center justify-center gap-1.5 text-[#45464f] text-xs text-center">
        <span className="material-symbols-outlined text-[16px] text-green-600">verified</span>
        <span>Encrypted submission • Direct NCUA charter verification</span>
      </div>
    </div>
  );
};
