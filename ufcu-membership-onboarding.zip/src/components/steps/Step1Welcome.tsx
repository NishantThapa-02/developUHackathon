import React, { useState, useEffect } from 'react';
import { OnboardingState } from '../../types';

interface Step1Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
}

export const Step1Welcome: React.FC<Step1Props> = ({ state, onUpdate, onNext }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        handleContinue();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state.intent]);

  const handleContinue = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onNext();
    }, 300);
  };

  const options = [
    {
      id: 'everyday' as const,
      icon: 'account_balance_wallet',
      title: 'Everyday banking',
      desc: 'Checking, high-yield debit, direct deposit, and free ATM access nationwide.'
    },
    {
      id: 'saving' as const,
      icon: 'savings',
      title: 'Start saving',
      desc: 'High-rate certificates, money markets, and automated goal savings buckets.'
    },
    {
      id: 'credit' as const,
      icon: 'verified',
      title: 'Build credit',
      desc: 'Low-interest reward credit cards and structured credit-builder personal loans.'
    },
    {
      id: 'auto' as const,
      icon: 'directions_car',
      title: 'Buy a car',
      desc: 'Pre-approved auto financing, refinancing discounts, and partner dealership perks.'
    },
    {
      id: 'home' as const,
      icon: 'real_estate_agent',
      title: 'Buy a home',
      desc: 'First-time buyer programs, competitive mortgage rates, and local lending advisors.'
    },
    {
      id: 'business' as const,
      icon: 'storefront',
      title: 'Manage a business',
      desc: 'Merchant processing, commercial lines of credit, and payroll-integrated accounts.'
    },
    {
      id: 'unsure' as const,
      icon: 'explore',
      title: 'I’m not sure yet',
      desc: 'Explore member-ownership perks, community benefits, and discover options as you go.'
    }
  ];

  return (
    <div className="relative w-full max-w-2xl mx-auto flex flex-col items-center animate-fadeIn">
      {/* Ambient brand glow behind main content */}
      <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-96 h-64 bg-gradient-to-b from-[#fc712a]/10 via-[#dae1ff]/20 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Conversational Intro Header */}
      <div className="w-full flex flex-col items-center text-center space-y-2 mb-8">
        {/* Stepper Pill & Secure Indicator */}
        <div className="flex items-center gap-2 mb-1">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e6e8ea] text-[#23335d] text-xs font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-[#fc712a] animate-pulse" />
            Step 1 of 10 • Welcome
          </span>
          <span className="inline-flex items-center gap-1 text-[#45464f] text-xs">
            <span className="material-symbols-outlined text-[14px] text-[#0b1d47]">verified_user</span>
            Official Membership
          </span>
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-4xl font-bold text-[#0b1d47] tracking-tight max-w-xl font-['Plus_Jakarta_Sans']">
          What brings you to UFCU today?
        </h1>

        {/* Conversational Subtitle */}
        <p className="text-base sm:text-lg text-[#45464f] max-w-lg leading-relaxed">
          Tell us what you’re looking for. We’ll help you find a good place to start.
        </p>
      </div>

      {/* Interactive Options Grid */}
      <fieldset aria-label="Membership Intent Options" className="w-full space-y-3 mb-8">
        <legend className="sr-only">Choose what you would like to accomplish with UFCU</legend>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full">
          {options.slice(0, 6).map((opt) => {
            const isSelected = state.intent === opt.id;
            return (
              <label
                key={opt.id}
                onClick={() => onUpdate({ intent: opt.id })}
                className={`group relative flex items-start gap-4 p-5 rounded-xl cursor-pointer transition-all duration-200 hover:-translate-y-0.5 select-none ${
                  isSelected
                    ? 'bg-[#ffdbcb]/30 shadow-md ring-2 ring-[#fc712a]'
                    : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
                }`}
              >
                <input
                  type="radio"
                  name="membership_intent"
                  value={opt.id}
                  checked={isSelected}
                  onChange={() => onUpdate({ intent: opt.id })}
                  className="sr-only"
                />
                <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                  isSelected ? 'bg-[#fc712a] text-white shadow-sm' : 'bg-[#eceef0] text-[#0b1d47] group-hover:bg-[#dae1ff]'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">{opt.icon}</span>
                </div>
                <div className="flex-1 min-w-0 pr-6">
                  <span className="font-semibold text-base text-[#0b1d47] tracking-tight block">
                    {opt.title}
                  </span>
                  <p className="text-xs text-[#45464f] mt-1 leading-relaxed">
                    {opt.desc}
                  </p>
                </div>
                <div className={`absolute top-4 right-4 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                  isSelected ? 'bg-[#fc712a] text-white shadow-sm' : 'bg-[#eceef0] text-transparent'
                }`}>
                  <span className="material-symbols-outlined text-[16px] font-bold">check</span>
                </div>
              </label>
            );
          })}
        </div>

        {/* Option 7: Full Width - Not Sure Yet */}
        {(() => {
          const opt = options[6];
          const isSelected = state.intent === opt.id;
          return (
            <label
              onClick={() => onUpdate({ intent: opt.id })}
              className={`group relative flex items-center justify-between p-5 rounded-xl cursor-pointer transition-all duration-200 hover:-translate-y-0.5 select-none ${
                isSelected
                  ? 'bg-[#ffdbcb]/30 shadow-md ring-2 ring-[#fc712a]'
                  : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
              }`}
            >
              <input
                type="radio"
                name="membership_intent"
                value={opt.id}
                checked={isSelected}
                onChange={() => onUpdate({ intent: opt.id })}
                className="sr-only"
              />
              <div className="flex items-center gap-4">
                <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                  isSelected ? 'bg-[#fc712a] text-white shadow-sm' : 'bg-[#eceef0] text-[#0b1d47] group-hover:bg-[#dae1ff]'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">{opt.icon}</span>
                </div>
                <div>
                  <span className="font-semibold text-base text-[#0b1d47] tracking-tight block">
                    {opt.title}
                  </span>
                  <p className="text-xs text-[#45464f] mt-0.5 leading-relaxed">
                    {opt.desc}
                  </p>
                </div>
              </div>
              <div className={`shrink-0 ml-4 w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                isSelected ? 'bg-[#fc712a] text-white shadow-sm' : 'bg-[#eceef0] text-transparent'
              }`}>
                <span className="material-symbols-outlined text-[16px] font-bold">check</span>
              </div>
            </label>
          );
        })()}
      </fieldset>

      {/* Action Console & Keyboard Prompt */}
      <div className="w-full flex flex-col items-center gap-4">
        <div className="w-full sm:w-auto flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            id="btn-continue"
            type="button"
            onClick={handleContinue}
            disabled={isSubmitting}
            className="w-full sm:w-72 h-14 bg-[#fc712a] hover:bg-[#e05a12] text-white font-semibold text-base rounded-xl shadow-md hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <span className="material-symbols-outlined animate-spin text-[20px]">progress_activity</span>
                <span>Saving preference...</span>
              </>
            ) : (
              <>
                <span>Continue</span>
                <span className="material-symbols-outlined text-[20px] transition-transform duration-200 group-hover:translate-x-1">arrow_forward</span>
              </>
            )}
          </button>
        </div>

        <div className="hidden sm:inline-flex items-center gap-1.5 text-[#45464f] text-xs">
          <span>Press</span>
          <kbd className="px-2 py-0.5 rounded bg-[#e6e8ea] text-[#0b1d47] font-semibold text-[11px] shadow-2xs">Enter ↵</kbd>
          <span>to proceed with selection</span>
        </div>

        {/* Member Care Guarantee Principle */}
        <div className="mt-4 w-full max-w-lg p-4 rounded-xl bg-[#f2f4f6] flex items-center gap-3.5 border border-slate-200/50">
          <div className="w-9 h-9 rounded-full bg-white text-[#0b1d47] flex items-center justify-center shrink-0 shadow-xs">
            <span className="material-symbols-outlined text-[20px]">shield_person</span>
          </div>
          <div className="min-w-0">
            <p className="text-xs text-[#0b1d47] font-semibold">Our Member Pledge</p>
            <p className="text-xs text-[#45464f] italic">
              “Never ask the member to do work UFCU can safely avoid.”
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
