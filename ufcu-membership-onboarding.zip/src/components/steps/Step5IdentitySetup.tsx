import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step5Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Step5IdentitySetup: React.FC<Step5Props> = ({ state, onUpdate, onNext, onPrev }) => {
  const [isRegulationOpen, setIsRegulationOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const handleSelectOption = (choice: 'scan' | 'digital' | 'manual') => {
    onUpdate({ verificationMethod: choice });
  };

  const handleTriggerScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      onNext();
    }, 700);
  };

  return (
    <div className="relative w-full max-w-xl mx-auto flex flex-col gap-6 animate-fadeIn">
      {/* Top Step Meta & Conversational Framing */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#eceef0] text-[#45464f] text-xs font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-[#fc712a] animate-pulse" />
            Step 5 of 10
          </span>
          <span className="text-slate-300 text-xs">•</span>
          <span className="text-[#45464f] text-xs uppercase tracking-wider font-semibold">Identity Setup</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight mt-1 font-['Plus_Jakarta_Sans']">
          Great choice. Let’s get you set up.
        </h1>
        <p className="text-sm sm:text-base text-[#45464f] max-w-lg leading-relaxed">
          To comply with federal credit union regulations and safeguard your identity, we need to verify who you are. It only takes about a minute.
        </p>
      </div>

      {/* Interactive Options Stack */}
      <div className="flex flex-col gap-3.5" id="verification-options">
        {/* Option 1: Hero / Recommended ID Scan */}
        <div
          onClick={() => handleSelectOption('scan')}
          className={`group relative rounded-2xl p-6 transition-all duration-200 cursor-pointer overflow-hidden select-none ${
            state.verificationMethod === 'scan'
              ? 'bg-white shadow-md ring-2 ring-[#fc712a]'
              : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
          }`}
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#fc712a]/10 rounded-full blur-2xl pointer-events-none -mr-8 -mt-8" />
          <div className="flex flex-col gap-4 relative z-10">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-[#ffdbcd] flex items-center justify-center text-[#360f00] shrink-0">
                  <span className="material-symbols-outlined text-[26px]">document_scanner</span>
                </div>
                <div className="flex flex-col">
                  <span className="inline-flex items-center w-fit px-2 py-0.5 mb-1 rounded-full bg-[#fc712a] text-white text-[10px] tracking-wide font-bold uppercase">
                    FASTEST • RECOMMENDED
                  </span>
                  <h3 className="text-base sm:text-lg font-semibold text-[#0b1d47] font-['Plus_Jakarta_Sans']">
                    Scan government-issued ID
                  </h3>
                </div>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors shrink-0 ${
                state.verificationMethod === 'scan' ? 'bg-[#ffdbcd]' : 'bg-[#e6e8ea]'
              }`}>
                <span className={`material-symbols-outlined text-[#fc712a] text-[18px] transition-opacity ${
                  state.verificationMethod === 'scan' ? 'opacity-100' : 'opacity-0'
                }`}>
                  check_circle
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              Use your device camera or take a quick photo of your Driver’s License or Passport. We’ll auto-populate your details so you don’t have to type them.
            </p>

            {/* Visual Camera Preview Prompt */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-1.5 text-[#45464f] text-xs">
                <span className="material-symbols-outlined text-[16px] text-[#a33e00]">bolt</span>
                <span>Takes ~60 seconds</span>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleTriggerScan();
                }}
                disabled={isScanning}
                className="inline-flex items-center gap-1.5 bg-[#fc712a] hover:bg-[#e05a12] text-white font-semibold text-xs sm:text-sm px-4 py-2 rounded-lg shadow-sm transition-all active:scale-[0.98] cursor-pointer"
              >
                {isScanning ? (
                  <>
                    <span className="material-symbols-outlined animate-spin text-[18px]">progress_activity</span>
                    <span>Starting camera...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[18px]">photo_camera</span>
                    <span>Scan ID now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Option 2: Digital Identity */}
        <div
          onClick={() => handleSelectOption('digital')}
          className={`group relative rounded-2xl p-5 transition-all duration-200 cursor-pointer select-none ${
            state.verificationMethod === 'digital'
              ? 'bg-white shadow-md ring-2 ring-[#fc712a]'
              : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-[#dae1ff] flex items-center justify-center text-[#061942] shrink-0">
                <span className="material-symbols-outlined text-[24px]">verified_user</span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-semibold text-[#0b1d47] font-['Plus_Jakarta_Sans']">
                    Digital Identity
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-[#eceef0] text-[#45464f] text-[10px] font-medium">
                    Supported States
                  </span>
                </div>
                <p className="text-xs text-[#45464f] leading-relaxed">
                  Connect directly using state-backed digital IDs, Apple Wallet, or state-approved mobile driver’s licenses.
                </p>
              </div>
            </div>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors shrink-0 ${
              state.verificationMethod === 'digital' ? 'bg-[#ffdbcd]' : 'bg-[#e6e8ea]'
            }`}>
              <span className={`material-symbols-outlined text-[#fc712a] text-[18px] transition-opacity ${
                state.verificationMethod === 'digital' ? 'opacity-100' : 'opacity-0'
              }`}>
                check_circle
              </span>
            </div>
          </div>
        </div>

        {/* Option 3: Manual Entry */}
        <div
          onClick={() => handleSelectOption('manual')}
          className={`group relative rounded-2xl p-5 transition-all duration-200 cursor-pointer select-none ${
            state.verificationMethod === 'manual'
              ? 'bg-white shadow-md ring-2 ring-[#fc712a]'
              : 'bg-white shadow-sm hover:shadow-md border border-slate-100'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-[#eceef0] flex items-center justify-center text-[#45464f] shrink-0">
                <span className="material-symbols-outlined text-[24px]">edit_note</span>
              </div>
              <div className="flex flex-col gap-1">
                <h3 className="text-base font-semibold text-[#0b1d47] font-['Plus_Jakarta_Sans']">
                  Enter information manually
                </h3>
                <p className="text-xs text-[#45464f] leading-relaxed">
                  Type your personal information and document details step-by-step. Verification may take slightly longer.
                </p>
              </div>
            </div>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors shrink-0 ${
              state.verificationMethod === 'manual' ? 'bg-[#ffdbcd]' : 'bg-[#e6e8ea]'
            }`}>
              <span className={`material-symbols-outlined text-[#fc712a] text-[18px] transition-opacity ${
                state.verificationMethod === 'manual' ? 'opacity-100' : 'opacity-0'
              }`}>
                check_circle
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Regulation Accordion */}
      <div className="rounded-xl bg-[#f2f4f6] border border-slate-200/50 transition-all duration-200 overflow-hidden shadow-2xs">
        <button
          type="button"
          onClick={() => setIsRegulationOpen(!isRegulationOpen)}
          className="w-full flex items-center justify-between p-4 text-left text-xs sm:text-sm font-semibold text-[#0b1d47] hover:text-[#fc712a] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px] text-[#45464f]">shield</span>
            <span>Why do we need this?</span>
          </div>
          <span className={`material-symbols-outlined text-[20px] transition-transform duration-200 ${
            isRegulationOpen ? 'rotate-180' : ''
          }`}>
            expand_more
          </span>
        </button>
        {isRegulationOpen && (
          <div className="px-4 pb-4 flex flex-col gap-2 animate-fadeIn text-xs text-[#45464f] border-t border-slate-200/40 pt-3">
            <p className="leading-relaxed">
              Federal regulations (USA PATRIOT Act and FinCEN guidelines) require all financial institutions to verify the identity of individuals opening an account. This protects our member-owners from fraud and ensures your money stays safe.
            </p>
            <div className="flex items-center gap-1.5 text-[#0b1d47] font-semibold pt-1">
              <span className="material-symbols-outlined text-[16px] text-[#a33e00]">verified</span>
              <span>UFCU never sells your biometric or identity data.</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Actions & Security Guarantee */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
        <button
          onClick={onPrev}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-[#23335d] hover:bg-[#eceef0] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>

        <button
          onClick={onNext}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#fc712a] hover:bg-[#e05a12] text-white text-xs font-bold shadow-md hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer"
        >
          <span>Continue</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>

      <div className="flex items-center justify-center gap-1.5 text-[#45464f] text-xs text-center">
        <span className="material-symbols-outlined text-[16px] text-[#0b1d47]">lock</span>
        <span>Bank-grade 256-bit encryption. Strict verification usage only.</span>
      </div>
    </div>
  );
};
