import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step10Props {
  state: OnboardingState;
  onReset: () => void;
}

export const Step10Complete: React.FC<Step10Props> = ({ state, onReset }) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const firstName = state.userInfo.fullName.split(' ')[0] || 'Elena';
  const fundedAmount = state.funding.method === 'later' ? 5 : state.funding.amount + 5;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-2xl mx-auto animate-fadeIn">
      {/* Top Congratulatory Header */}
      <div className="flex flex-col items-center text-center gap-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffdbcd] text-[#a33e00] text-xs font-bold uppercase tracking-wider">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">celebration</span>
          <span>Welcome to UFCU</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          Welcome to the family, {firstName}.
        </h1>
        <p className="text-sm sm:text-base text-[#45464f] max-w-md">
          Your official UFCU membership and accounts are officially open and active.
        </p>
      </div>

      {/* Hero Digital Member Card Graphic */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b1d47] via-[#23335d] to-[#364570] p-6 sm:p-8 text-white shadow-2xl border border-slate-700">
        {/* Decorative Gradient Overlay & Card Elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#fc712a]/20 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#ffdbcd]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col justify-between gap-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <img 
                alt="UFCU Badge" 
                className="h-8 w-auto brightness-200" 
                src="https://lh3.googleusercontent.com/aida/AEtjO1WtPSTkb8ucwtZ_jUmoEXjUaCE1Yrv1g_NWC0xENBC4ve3dBIHzXfhh4KLnx9OUxcvrsWkDUMCbF4UgPmd9ZwGxoVAB0jSjs8silpAYbIRdeQI0jinRT0ZHcyP15QcA3hEhCCvweFzwXuLgmMrqzm2u7uiMhMgFDtMdCHsb_BBq87X6H-ksGB3K7U6oML-qqzvUvlIonaj5bmE9PiuT9hHkBbZUMs_kLXzK6zJ03hM37CpjDeEoheyw3Ek"
              />
              <span className="text-xs uppercase tracking-widest text-[#ffdbcd] font-semibold">
                Member-Owner
              </span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full backdrop-blur-xs text-[11px] font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>ACTIVE</span>
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-[10px] uppercase tracking-widest text-[#8d9ccd]">Account Holder</span>
            <span className="text-xl sm:text-2xl font-bold font-['Plus_Jakarta_Sans'] tracking-tight text-white">
              {state.userInfo.fullName}
            </span>
          </div>

          {/* Account & Routing Numbers Box with One-click Copy */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-white/15 text-xs">
            <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-xs flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] text-[#8d9ccd] uppercase tracking-wider">Member ID</span>
                <span className="font-mono font-bold text-white text-xs">8492-0194</span>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard('84920194', 'Member ID')}
                className="p-1 hover:bg-white/20 rounded text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="Copy Member ID"
              >
                <span className="material-symbols-outlined text-[16px]">
                  {copiedField === 'Member ID' ? 'check' : 'content_copy'}
                </span>
              </button>
            </div>

            <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-xs flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] text-[#8d9ccd] uppercase tracking-wider">Routing (RTN)</span>
                <span className="font-mono font-bold text-white text-xs">314088921</span>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard('314088921', 'Routing Number')}
                className="p-1 hover:bg-white/20 rounded text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="Copy Routing Number"
              >
                <span className="material-symbols-outlined text-[16px]">
                  {copiedField === 'Routing Number' ? 'check' : 'content_copy'}
                </span>
              </button>
            </div>

            <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-xs flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] text-[#8d9ccd] uppercase tracking-wider">Checking Balance</span>
                <span className="font-mono font-bold text-[#ffdbcd] text-xs">${fundedAmount}.00</span>
              </div>
              <span className="text-[10px] text-emerald-300 font-semibold">Available</span>
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps Quick Action Grid */}
      <div className="flex flex-col gap-3">
        <h3 className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider px-1">
          Recommended Next Steps
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Card 1: Wallet */}
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between gap-3 hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-[#ffdbcd] text-[#360f00] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">contactless</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#0b1d47]">Add to Wallet</h4>
              <p className="text-xs text-[#45464f] mt-1">
                Your digital debit card is ready to use today on Apple Pay or Google Wallet.
              </p>
            </div>
            <button
              type="button"
              onClick={() => alert('Digital card sent to your Apple/Google Wallet!')}
              className="w-full py-2 bg-[#f2f4f6] hover:bg-[#eceef0] text-[#0b1d47] rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Add Card Now
            </button>
          </div>

          {/* Card 2: Mobile App */}
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between gap-3 hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-[#dae1ff] text-[#061942] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">smartphone</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#0b1d47]">Get Mobile App</h4>
              <p className="text-xs text-[#45464f] mt-1">
                Download the top-rated UFCU mobile app for biometric login and spending insights.
              </p>
            </div>
            <button
              type="button"
              onClick={() => alert('A direct mobile download link has been sent to your phone!')}
              className="w-full py-2 bg-[#f2f4f6] hover:bg-[#eceef0] text-[#0b1d47] rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Send App Link
            </button>
          </div>

          {/* Card 3: Direct Deposit */}
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between gap-3 hover:shadow-md transition-shadow">
            <div className="w-10 h-10 rounded-xl bg-[#ffb596] text-[#360f00] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">payments</span>
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#0b1d47]">Switch Paycheck</h4>
              <p className="text-xs text-[#45464f] mt-1">
                Unlock paychecks up to 2 days early with pre-filled direct deposit switch form.
              </p>
            </div>
            <button
              type="button"
              onClick={() => alert('Direct Deposit switch form generated and emailed to your inbox!')}
              className="w-full py-2 bg-[#f2f4f6] hover:bg-[#eceef0] text-[#0b1d47] rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Get PDF Form
            </button>
          </div>
        </div>
      </div>

      {/* Community & Campus Lifestyle Photo Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-white border border-slate-100 shadow-sm p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-4">
        <img
          alt="Central Texas lifestyle member"
          className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shrink-0 shadow-xs"
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuAhpyvB1V1btMNuL-V1avT-1QIsUgOBve_oeDfP-0Sn93EI1uGLvP30S7kHbpuKh_bgtk5Wdr8Vm1TPMl2x4vMKCWFzo2w9nFzp6Wj9Jyy-ZBe4YxXABB6UDq3HcK5GG0tYSqDiCSTNxLhOZnEkl-qSPs2d_VeGgatgoGETbQtGMnXmKIcQdV-Hj4lSeI5U0bGSPkSJ-Pt9TGEuxfbM779DX-zH_zMKtgZUJL8yjT0WwpEwUsOljtGL"
        />
        <div className="flex flex-col gap-1 text-center sm:text-left">
          <span className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Proudly Central Texas
          </span>
          <h4 className="font-bold text-sm text-[#0b1d47]">
            You’re not just a customer. You’re an owner.
          </h4>
          <p className="text-xs text-[#45464f] leading-relaxed">
            As a cooperative credit union member, every dollar of UFCU profit returns to you in lower loan rates, higher deposit yields, and local scholarships.
          </p>
        </div>
      </div>

      {/* Actions */}
      <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
        <button
          type="button"
          onClick={() => alert('Redirecting to your new UFCU Digital Banking dashboard...')}
          className="w-full sm:w-72 h-13 bg-[#fc712a] hover:bg-[#e05a12] text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Go to Member Dashboard</span>
          <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
        </button>

        <button
          type="button"
          onClick={onReset}
          className="w-full sm:w-auto px-5 h-13 bg-white hover:bg-slate-50 text-[#23335d] border border-slate-200 font-semibold text-xs rounded-xl shadow-2xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">restart_alt</span>
          <span>Start New Application</span>
        </button>
      </div>
    </div>
  );
};
