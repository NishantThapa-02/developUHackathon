import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step4Props {
  state: OnboardingState;
  onNext: () => void;
  onPrev: () => void;
}

export const Step4Recommendation: React.FC<Step4Props> = ({ state, onNext, onPrev }) => {
  const [isAccordionOpen, setIsAccordionOpen] = useState(false);
  const [showCompareModal, setShowCompareModal] = useState(false);

  return (
    <div className="flex flex-col w-full max-w-3xl mx-auto animate-fadeIn">
      {/* Progress Header & Eyebrow Tracker */}
      <div className="flex flex-col gap-1 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[#23335d] text-white text-xs font-bold">
              4
            </span>
            <span className="text-xs text-[#23335d] uppercase tracking-wider font-semibold">
              Step 4 of 10 • Recommendation
            </span>
          </div>
          <div className="flex items-center gap-1">
            <span className="inline-block w-6 h-1.5 rounded-full bg-[#23335d]" />
            <span className="inline-block w-6 h-1.5 rounded-full bg-[#23335d]" />
            <span className="inline-block w-6 h-1.5 rounded-full bg-[#23335d]" />
            <span className="inline-block w-8 h-1.5 rounded-full bg-[#fc712a]" />
            <span className="inline-block w-4 h-1.5 rounded-full bg-[#e6e8ea]" />
            <span className="inline-block w-4 h-1.5 rounded-full bg-[#e6e8ea]" />
          </div>
        </div>
        <div className="mt-2 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
            Here’s a good fit based on what you told us.
          </h1>
          <p className="text-sm sm:text-base text-[#45464f] max-w-xl">
            We matched your priorities with UFCU’s most flexible everyday account.
          </p>
        </div>
      </div>

      {/* Primary Recommendation Bento Container */}
      <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 relative overflow-hidden flex flex-col gap-6 border border-slate-100">
        {/* Subtle Ambient Corner Accents */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#ffdbcd]/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-56 h-56 bg-[#dae1ff]/30 rounded-full blur-2xl pointer-events-none" />

        {/* Match Badges & Main Title Ribbon */}
        <div className="flex flex-wrap items-center justify-between gap-3 relative z-10">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#fc712a] text-white text-xs font-semibold shadow-xs">
              <span className="material-symbols-outlined text-[16px]">verified</span>
              <span>Best Match: 98% Compatibility</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f2f4f6] text-[#23335d] text-xs font-medium">
              <span className="material-symbols-outlined text-[16px] text-[#fc712a]">savings</span>
              <span>No Monthly Service Fee</span>
            </div>
          </div>
          <span className="text-[11px] text-[#45464f] uppercase tracking-widest font-semibold flex items-center gap-1">
            <span className="inline-block w-2 h-2 rounded-full bg-[#fc712a] animate-pulse" />
            Member Tier 01
          </span>
        </div>

        {/* Account Visual Identity Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center relative z-10">
          <div className="lg:col-span-8 flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-xs">
              <span className="px-2 py-0.5 rounded bg-[#e6e8ea] text-[#45464f] font-semibold text-[10px]">DUAL SUITE</span>
              <span className="text-slate-300">•</span>
              <span className="text-[#75767f]">Checking + Yield Vault</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
              UFCU Free Checking + High-Yield Member Savings
            </h2>
            <p className="text-xs sm:text-sm text-[#45464f] leading-relaxed">
              A simple, fee-free account designed for effortless everyday spending, paired with automated high-yield savings to grow your surplus.
            </p>
          </div>

          {/* Illustrated Mini Card Visual (Fintech aesthetic) */}
          <div className="lg:col-span-4 flex justify-center lg:justify-end">
            <div className="w-full max-w-[240px] h-36 bg-gradient-to-br from-[#0b1d47] to-[#23335d] rounded-xl p-4 text-white shadow-lg flex flex-col justify-between relative overflow-hidden transform hover:-translate-y-1 transition-transform">
              <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-[#fc712a]/25 rounded-full blur-lg" />
              <div className="flex items-center justify-between">
                <span className="text-sm tracking-widest font-bold opacity-90 font-['Plus_Jakarta_Sans']">UFCU</span>
                <span className="material-symbols-outlined text-[#ffdbcd] text-[22px]">contactless</span>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] tracking-wider opacity-70 uppercase font-semibold">MEMBER PRIVILEGE</div>
                <div className="flex items-center justify-between text-xs tracking-wider font-mono">
                  <span>•••• 4820</span>
                  <span className="text-[#ffdbcd] font-semibold">4.25% APY</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* "Why This Fits You" Intent Callout */}
        <div className="rounded-xl bg-[#ffdbcb]/30 p-4 shadow-2xs relative z-10 border border-[#ffb691]/40">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-[#fc712a] text-white flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">psychology</span>
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-xs text-[#0b1d47] font-bold uppercase tracking-wider">Why this fits you</span>
              <p className="text-xs sm:text-sm text-[#23335d] italic leading-relaxed">
                “You told us you want everyday spending, direct deposit, and minimal fees. This option aligns with those priorities.”
              </p>
            </div>
          </div>
        </div>

        {/* Key Core Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 relative z-10">
          <div className="p-3.5 rounded-xl bg-[#f2f4f6] flex items-start gap-3 hover:bg-[#eceef0] transition-colors">
            <div className="w-7 h-7 rounded-full bg-white text-[#fc712a] flex items-center justify-center shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-[18px]">check_circle</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs sm:text-sm text-[#0b1d47] font-semibold">$0 Monthly Maintenance</span>
              <span className="text-[11px] sm:text-xs text-[#45464f]">No minimum balance rules or unexpected balance penalties.</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#f2f4f6] flex items-start gap-3 hover:bg-[#eceef0] transition-colors">
            <div className="w-7 h-7 rounded-full bg-white text-[#fc712a] flex items-center justify-center shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-[18px]">bolt</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs sm:text-sm text-[#0b1d47] font-semibold">2 Days Early Pay</span>
              <span className="text-[11px] sm:text-xs text-[#45464f]">Get paid up to 2 days early with UFCU Free Direct Deposit.</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#f2f4f6] flex items-start gap-3 hover:bg-[#eceef0] transition-colors">
            <div className="w-7 h-7 rounded-full bg-white text-[#fc712a] flex items-center justify-center shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-[18px]">atm</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs sm:text-sm text-[#0b1d47] font-semibold">55,000+ Free ATMs</span>
              <span className="text-[11px] sm:text-xs text-[#45464f]">Nationwide access through surcharge-free Allpoint® network.</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#f2f4f6] flex items-start gap-3 hover:bg-[#eceef0] transition-colors">
            <div className="w-7 h-7 rounded-full bg-white text-[#fc712a] flex items-center justify-center shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-[18px]">trending_up</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs sm:text-sm text-[#0b1d47] font-semibold">4.25% APY Surplus Growth</span>
              <span className="text-[11px] sm:text-xs text-[#45464f]">Automatic round-up savings on your initial $1,000 balance.</span>
            </div>
          </div>
        </div>

        {/* Transparency Section: Algorithm Breakdown Accordion */}
        <div className="relative z-10">
          <button
            type="button"
            onClick={() => setIsAccordionOpen(!isAccordionOpen)}
            aria-expanded={isAccordionOpen}
            className="w-full text-left bg-[#f2f4f6] hover:bg-[#eceef0] px-4 py-3 rounded-xl flex items-center justify-between transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#23335d] text-[20px] group-hover:rotate-12 transition-transform">insights</span>
              <span className="text-xs sm:text-sm text-[#0b1d47] font-semibold">
                Why this recommendation? (Click to view matching algorithm breakdown)
              </span>
            </div>
            <span className={`material-symbols-outlined text-[#23335d] text-[20px] transition-transform duration-200 ${
              isAccordionOpen ? 'rotate-180' : ''
            }`}>
              expand_more
            </span>
          </button>

          {isAccordionOpen && (
            <div className="mt-2 p-4 rounded-xl bg-[#eceef0] text-[#191c1e] flex flex-col gap-2 animate-fadeIn">
              <div className="flex items-center justify-between pb-1 text-xs">
                <span className="text-[#45464f] font-bold uppercase tracking-wider text-[10px]">Matching Parameters Applied</span>
                <span className="text-[#a33e00] font-semibold text-[10px]">Deterministic Fit Matrix</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between bg-white p-2.5 rounded-lg shadow-2xs">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#fc712a] text-[18px]">done_all</span>
                    <span className="text-[#0b1d47] font-medium">$0 Maintenance Fee Filter</span>
                  </div>
                  <span className="text-[#a33e00] font-bold">Saves ~$144/year</span>
                </div>
                <div className="flex items-center justify-between bg-white p-2.5 rounded-lg shadow-2xs">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#fc712a] text-[18px]">done_all</span>
                    <span className="text-[#0b1d47] font-medium">Payroll Routing & Early Liquidity</span>
                  </div>
                  <span className="text-[#0b1d47] font-semibold">Direct Deposit Priority</span>
                </div>
                <div className="flex items-center justify-between bg-white p-2.5 rounded-lg shadow-2xs">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#fc712a] text-[18px]">done_all</span>
                    <span className="text-[#0b1d47] font-medium">Cooperative Member Dividend Pool</span>
                  </div>
                  <span className="text-[#0b1d47] font-semibold">Tier 1 Returns</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* CTA Tray */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-1 relative z-10">
          <button
            onClick={onNext}
            type="button"
            className="w-full sm:flex-1 bg-[#fc712a] hover:bg-[#e05a12] text-white font-bold text-sm sm:text-base h-13 rounded-xl shadow-md hover:shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Open Account</span>
            <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
          </button>
          <button
            onClick={() => setShowCompareModal(true)}
            type="button"
            className="w-full sm:w-auto px-6 bg-white hover:bg-slate-50 text-[#23335d] border border-slate-200 font-bold text-sm h-13 rounded-xl shadow-2xs active:scale-[0.98] transition-all flex items-center justify-center cursor-pointer"
          >
            Compare options
          </button>
        </div>

        {/* Assurance Disclaimer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1 text-center sm:text-left relative z-10 text-xs text-[#45464f]">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#23335d]">tune</span>
            <span>You can change or add accounts at any point.</span>
          </div>
          <div className="text-slate-400">
            No hard credit inquiry required to preview or select.
          </div>
        </div>
      </div>

      {/* Secondary Trust Footer Card */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl shadow-2xs border border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#eceef0] flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[#23335d] text-[20px]">security</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-[#0b1d47]">NCUA Backed</span>
            <span className="text-[11px] text-[#45464f]">Insured up to $250,000</span>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-2xs border border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#eceef0] flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[#fc712a] text-[20px]">support_agent</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-[#0b1d47]">Local Human Support</span>
            <span className="text-[11px] text-[#45464f]">Austin & Central Texas team</span>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-2xs border border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#eceef0] flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[#23335d] text-[20px]">sync</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-[#0b1d47]">Instant Digital Card</span>
            <span className="text-[11px] text-[#45464f]">Apple Pay & Google Wallet</span>
          </div>
        </div>
      </div>

      {/* Compare Modal */}
      {showCompareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 relative border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-[#0b1d47] font-['Plus_Jakarta_Sans']">Account Options Comparison</h3>
                <p className="text-xs text-[#45464f]">UFCU Checking & Savings Options</p>
              </div>
              <button 
                onClick={() => setShowCompareModal(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl border-2 border-[#fc712a] bg-orange-50/20 flex flex-col justify-between">
                <div>
                  <span className="px-2 py-0.5 rounded bg-[#fc712a] text-white text-[10px] font-bold">RECOMMENDED</span>
                  <h4 className="font-bold text-sm text-[#0b1d47] mt-1.5">Free Checking + High-Yield Savings</h4>
                  <ul className="mt-3 space-y-2 text-[#45464f]">
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>$0 Monthly fee with no minimums</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>4.25% APY high-yield rate</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>55,000+ fee-free Allpoint ATMs</span>
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => {
                    setShowCompareModal(false);
                    onNext();
                  }}
                  className="mt-4 w-full py-2 bg-[#fc712a] text-white rounded-lg font-semibold hover:bg-[#e05a12] transition-colors cursor-pointer"
                >
                  Keep Selected
                </button>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
                <div>
                  <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-[10px] font-semibold">PREMIUM CASHBACK</span>
                  <h4 className="font-bold text-sm text-[#0b1d47] mt-1.5">Rewards Checking</h4>
                  <ul className="mt-3 space-y-2 text-[#45464f]">
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>1.5% cashback on everyday debit card purchases</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>$5/mo waived with $500 monthly spend</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-green-600">check</span>
                      <span>Cell phone protection coverage</span>
                    </li>
                  </ul>
                </div>
                <button
                  onClick={() => {
                    setShowCompareModal(false);
                    onNext();
                  }}
                  className="mt-4 w-full py-2 bg-slate-200 text-[#0b1d47] rounded-lg font-semibold hover:bg-slate-300 transition-colors cursor-pointer"
                >
                  Select Rewards Checking
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
