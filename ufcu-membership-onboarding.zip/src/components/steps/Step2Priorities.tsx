import React from 'react';
import { OnboardingState } from '../../types';

interface Step2Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Step2Priorities: React.FC<Step2Props> = ({ state, onUpdate, onNext, onPrev }) => {
  const priorityCards = [
    {
      id: 'fees',
      icon: 'verified',
      title: 'No monthly fees',
      desc: 'Keep 100% of what you earn with transparent zero-maintenance accounts.',
      badge: 'Fee-free guarantee'
    },
    {
      id: 'access',
      icon: 'local_atm',
      title: 'Easy access to money',
      desc: 'Surcharge-free withdrawals nationwide and lightning-fast digital transfers.',
      badge: '55k+ Free ATMs'
    },
    {
      id: 'savings',
      icon: 'trending_up',
      title: 'Grow my savings',
      desc: 'Automate stash habits and unlock industry-leading high yield dividends.',
      badge: 'Competitive APY'
    },
    {
      id: 'paycheck',
      icon: 'payments',
      title: 'Receive my paycheck',
      desc: 'Access payroll up to 2 days sooner with automatic direct deposit setup.',
      badge: 'Up to 2 Days Early'
    },
    {
      id: 'credit',
      icon: 'speed',
      title: 'Build credit',
      desc: 'Graduated secured lines and real-time score tracking that builds power.',
      badge: 'Credit Health Tool'
    },
    {
      id: 'simple',
      icon: 'phonelink_setup',
      title: 'Keep things simple',
      desc: 'Consolidate balances, cards, and budgeting into one frictionless app.',
      badge: 'Top-rated mobile UI'
    }
  ];

  const togglePriority = (id: string) => {
    const exists = state.priorities.includes(id);
    let updated: string[];
    if (exists) {
      updated = state.priorities.filter((p) => p !== id);
    } else {
      updated = [...state.priorities, id];
    }
    onUpdate({ priorities: updated });
  };

  const intentLabels: Record<string, string> = {
    everyday: 'Everyday banking',
    saving: 'Start saving',
    credit: 'Build credit',
    auto: 'Buy a car',
    home: 'Buy a home',
    business: 'Manage a business',
    unsure: 'Exploring options'
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto flex flex-col gap-y-6 animate-fadeIn">
      <div className="flex flex-col gap-y-2">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#e6e8ea] text-[#45464f] text-xs uppercase tracking-wider font-semibold">
            <span className="w-2 h-2 rounded-full bg-[#fc712a]" />
            Step 2 of 10 • Priorities
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eceef0] text-[#364570] text-xs">
            <span className="material-symbols-outlined text-[14px]">history</span>
            <span>From: {intentLabels[state.intent] || 'Everyday banking'}</span>
          </div>
        </div>

        <h1 className="text-3xl sm:text-4xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          Got it. What matters most to you?
        </h1>
        <p className="text-base sm:text-lg text-[#45464f] leading-relaxed">
          Select everything that applies. We’ll tailor your accounts to fit your day-to-day rhythm.
        </p>
      </div>

      <div className="relative grid grid-cols-1 sm:grid-cols-2 gap-3.5" id="priority-options">
        {priorityCards.map((card) => {
          const isSelected = state.priorities.includes(card.id);
          return (
            <button
              key={card.id}
              type="button"
              onClick={() => togglePriority(card.id)}
              className={`priority-card group text-left relative flex flex-col justify-between p-5 rounded-xl shadow-sm transition-all duration-200 cursor-pointer select-none ${
                isSelected
                  ? 'bg-[#ffdbcb]/30 shadow-md ring-2 ring-[#fc712a]'
                  : 'bg-white hover:shadow-md border border-slate-100'
              }`}
            >
              <div className="flex items-start justify-between w-full mb-3.5">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center shadow-xs transition-colors ${
                  isSelected ? 'bg-[#fc712a] text-white' : 'bg-[#e6e8ea] text-[#0b1d47] group-hover:bg-[#dae1ff]'
                }`}>
                  <span className="material-symbols-outlined text-[24px]">{card.icon}</span>
                </div>
                <div className={`check-pill flex items-center justify-center w-6 h-6 rounded-full transition-all ${
                  isSelected ? 'bg-[#fc712a] text-white' : 'bg-[#eceef0] text-transparent'
                }`}>
                  <span className="material-symbols-outlined text-[16px] font-bold">check</span>
                </div>
              </div>

              <div className="flex flex-col gap-y-1">
                <span className="text-base font-semibold text-[#0b1d47] group-hover:text-[#fc712a] transition-colors">
                  {card.title}
                </span>
                <span className="text-xs text-[#45464f] leading-relaxed">
                  {card.desc}
                </span>
              </div>

              <div className="mt-4 pt-3 flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                  isSelected ? 'bg-white text-[#a33e00] shadow-2xs' : 'bg-[#eceef0] text-[#45464f]'
                }`}>
                  {card.badge}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Interactive Bottom Bar */}
      <div className="mt-2 flex flex-col gap-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-xl bg-white shadow-sm border border-slate-100">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0b1d47] text-white text-xs font-semibold">
              <span className="material-symbols-outlined text-[16px]">check_circle</span>
              <span>{state.priorities.length} selected</span>
            </span>
            <span className="hidden md:inline text-xs text-[#45464f]">
              Tailoring your setup in real-time
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onPrev}
              type="button"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">arrow_back</span>
              Back
            </button>
            <button
              onClick={onNext}
              type="button"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#fc712a] hover:bg-[#e05a12] text-white text-xs font-semibold shadow-md hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>Continue to Recommendation</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-center text-[#45464f] text-xs">
          <span className="material-symbols-outlined text-[16px] text-[#fc712a]">verified_user</span>
          <span>You can adjust these preferences anytime after opening your account.</span>
        </div>
      </div>
    </div>
  );
};
