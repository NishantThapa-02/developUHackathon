import React, { useState } from 'react';
import { OnboardingState } from '../../types';

interface Step7Props {
  state: OnboardingState;
  onUpdate: (updates: Partial<OnboardingState>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export const Step7FinalDetails: React.FC<Step7Props> = ({ state, onUpdate, onNext, onPrev }) => {
  const [showSSN, setShowSSN] = useState(false);

  const handleUserInfoChange = (field: keyof OnboardingState['userInfo'], val: string) => {
    onUpdate({
      userInfo: {
        ...state.userInfo,
        [field]: val
      }
    });
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl mx-auto animate-fadeIn">
      {/* Top Heading */}
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#a33e00] font-semibold">
            Step 7 of 10 • Final Details
          </span>
          <span className="text-slate-300 text-xs">•</span>
          <span className="text-[#45464f] text-xs">Profile Completion</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#0b1d47] tracking-tight font-['Plus_Jakarta_Sans']">
          Just a few final details.
        </h1>
        <p className="text-sm sm:text-base text-[#45464f]">
          These remaining items complete your member profile for tax reporting and account notifications.
        </p>
      </div>

      {/* Main Input Form Card */}
      <div className="bg-white rounded-2xl shadow-md p-5 sm:p-7 flex flex-col gap-5 border border-slate-100">
        {/* Field 1: SSN / ITIN */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="ssn-input" className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider flex items-center justify-between">
            <span>Social Security Number (SSN / ITIN)</span>
            <span className="text-slate-400 font-normal normal-case text-[11px] flex items-center gap-1">
              <span className="material-symbols-outlined text-[13px] text-[#fc712a]">lock</span>
              256-bit encrypted
            </span>
          </label>
          <div className="relative flex items-center">
            <input
              id="ssn-input"
              type={showSSN ? 'text' : 'password'}
              value={state.userInfo.ssn}
              onChange={(e) => handleUserInfoChange('ssn', e.target.value)}
              placeholder="•••-••-••••"
              className="w-full h-12 px-4 pr-12 rounded-xl bg-[#f2f4f6] text-sm text-[#0b1d47] font-mono border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#fc712a] transition-all"
            />
            <button
              type="button"
              onClick={() => setShowSSN(!showSSN)}
              className="absolute right-3 p-1.5 text-slate-400 hover:text-[#0b1d47] transition-colors cursor-pointer"
              title={showSSN ? 'Hide SSN' : 'Reveal SSN'}
            >
              <span className="material-symbols-outlined text-[20px]">
                {showSSN ? 'visibility_off' : 'visibility'}
              </span>
            </button>
          </div>
          <p className="text-[11px] text-[#45464f] mt-0.5">
            Required by the IRS for interest reporting (Form 1099-INT). We never run an unauthorized credit pull.
          </p>
        </div>

        {/* Field 2: Primary Email */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="email-input" className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Primary Email Address
          </label>
          <div className="relative flex items-center">
            <span className="absolute left-3.5 material-symbols-outlined text-[18px] text-slate-400">mail</span>
            <input
              id="email-input"
              type="email"
              value={state.userInfo.email}
              onChange={(e) => handleUserInfoChange('email', e.target.value)}
              placeholder="name@domain.com"
              className="w-full h-12 pl-10 pr-4 rounded-xl bg-[#f2f4f6] text-sm text-[#0b1d47] border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#fc712a] transition-all font-medium"
            />
          </div>
          <p className="text-[11px] text-[#45464f] mt-0.5">
            We’ll send your official account credentials, welcome package, and monthly e-statements here.
          </p>
        </div>

        {/* Field 3: Mobile Phone */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="phone-input" className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Mobile Phone Number
          </label>
          <div className="relative flex items-center">
            <span className="absolute left-3.5 material-symbols-outlined text-[18px] text-slate-400">phone_iphone</span>
            <input
              id="phone-input"
              type="tel"
              value={state.userInfo.phone}
              onChange={(e) => handleUserInfoChange('phone', e.target.value)}
              placeholder="(512) 000-0000"
              className="w-full h-12 pl-10 pr-4 rounded-xl bg-[#f2f4f6] text-sm text-[#0b1d47] border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#fc712a] transition-all font-medium"
            />
          </div>
          <p className="text-[11px] text-[#45464f] mt-0.5">
            Used for two-factor authentication security codes and instant fraud detection notifications.
          </p>
        </div>

        {/* Field 4: Employment Status */}
        <div className="flex flex-col gap-1.5">
          <label htmlFor="employment-select" className="text-xs font-bold text-[#0b1d47] uppercase tracking-wider">
            Employment Status
          </label>
          <div className="relative flex items-center">
            <span className="absolute left-3.5 material-symbols-outlined text-[18px] text-slate-400">work</span>
            <select
              id="employment-select"
              value={state.userInfo.employmentStatus}
              onChange={(e) => handleUserInfoChange('employmentStatus', e.target.value as any)}
              className="w-full h-12 pl-10 pr-10 rounded-xl bg-[#f2f4f6] text-sm text-[#0b1d47] border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#fc712a] transition-all appearance-none font-medium cursor-pointer"
            >
              <option value="full-time">Employed Full-Time</option>
              <option value="self-employed">Self-Employed / Independent Contractor</option>
              <option value="student">Student</option>
              <option value="other">Retired / Other</option>
            </select>
            <span className="absolute right-3.5 material-symbols-outlined text-[20px] text-slate-400 pointer-events-none">
              expand_more
            </span>
          </div>
        </div>
      </div>

      {/* Trust Shield Banner */}
      <div className="p-4 rounded-xl bg-white border border-slate-100 shadow-2xs flex items-center gap-3.5">
        <img
          alt="Security shield illustration"
          className="w-12 h-12 object-contain shrink-0"
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuAbPsvGePAST3Tr4nWJE2N8WayzOTofUs_BAcmIuZmgOcZ2RwunOsEVIaZaqq8uhaGutz3oewyRjkXomJM1eCB4Ssem4W3yjhSdiGuZ148Q6bzyTct1ilUbccTU2UXQLOEg3jnsGfLbDiBY682zJWTorQYwILk58fTnqy0XztUNb3D9E1LFTMd9S0YlkFWv9GrXHdKzMOmPISeae7iBPwwhl2JICaRqpIILev95rTRao6gChyMAVCvM"
        />
        <div className="text-xs">
          <span className="font-bold text-[#0b1d47] block">Zero spam guarantee</span>
          <span className="text-[#45464f]">
            UFCU never sells member data or shares your phone number with external marketers. Your privacy is paramount.
          </span>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="pt-2 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
        <button
          onClick={onPrev}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#e6e8ea] hover:bg-slate-200 text-[#0b1d47] text-xs font-semibold transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span>Back</span>
        </button>
        <button
          onClick={onNext}
          type="button"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl bg-[#fc712a] hover:bg-[#e05a12] text-white shadow-md hover:shadow-lg font-bold text-xs sm:text-sm transition-all active:scale-[0.98] cursor-pointer"
        >
          <span>Review Application</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};
