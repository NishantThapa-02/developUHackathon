import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#f7f9fb] py-6 border-t border-slate-200/60 mt-auto">
      <div className="max-w-4xl mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-[#45464f] text-xs font-medium">
          <div className="inline-flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-[#23335d]">lock</span>
            <span>256-bit Bank-grade Encryption</span>
          </div>
          <span className="hidden sm:inline">•</span>
          <span>Federally Insured by NCUA</span>
          <span className="hidden sm:inline">•</span>
          <span>Equal Housing Opportunity</span>
        </div>
        <div className="text-xs text-[#45464f]">
          © 2024 UFCU. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
};
