import React from 'react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-fadeIn">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 relative flex flex-col gap-4 border border-slate-200"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#fc712a]/10 text-[#fc712a] flex items-center justify-center">
              <span className="material-symbols-outlined text-[24px]">support_agent</span>
            </div>
            <div>
              <h3 className="font-bold text-lg text-[#0b1d47] font-['Plus_Jakarta_Sans']">UFCU Member Support</h3>
              <p className="text-xs text-[#45464f]">Austin & Central Texas Member Advisory</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close help modal"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="space-y-3.5 text-sm text-[#45464f]">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <h4 className="font-semibold text-[#0b1d47] mb-1 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#fc712a]">verified_user</span>
              Who is eligible for membership?
            </h4>
            <p className="text-xs leading-relaxed">
              Anyone who lives, works, worships, or attends school in Central Texas or Galveston County, as well as students, faculty, staff, and alumni of UT Austin and partner universities.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <h4 className="font-semibold text-[#0b1d47] mb-1 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#23335d]">badge</span>
              What ID credentials can I use?
            </h4>
            <p className="text-xs leading-relaxed">
              Valid Texas Driver’s License, State ID, US Passport, or state-backed digital mobile IDs. Our automated verification parses your details in under 60 seconds.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
            <h4 className="font-semibold text-[#0b1d47] mb-1 flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px] text-[#23335d]">lock</span>
              Is my SSN and information safe?
            </h4>
            <p className="text-xs leading-relaxed">
              All communications are encrypted using bank-grade AES-256 bit encryption. UFCU never sells your biometric or identity data. Your deposits are federally insured by the NCUA up to $250,000.
            </p>
          </div>

          <div className="p-3 bg-[#ffdbcb]/30 rounded-xl border border-[#ffb691]/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#fc712a] text-[20px]">call</span>
              <div>
                <div className="font-semibold text-xs text-[#3a1400]">Prefer to talk to a local team member?</div>
                <div className="text-[11px] text-[#5c2400]">Mon–Fri 8am–6pm CT • (512) 467-8080</div>
              </div>
            </div>
            <a 
              href="tel:5124678080"
              className="px-3 py-1.5 bg-[#fc712a] text-white rounded-lg text-xs font-semibold hover:bg-[#e05a12] transition-colors"
            >
              Call Now
            </a>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button 
            onClick={onClose}
            className="px-5 py-2.5 bg-[#23335d] text-white rounded-xl text-xs font-semibold hover:bg-[#0b1d47] transition-all cursor-pointer"
          >
            Got it, back to application
          </button>
        </div>
      </div>
    </div>
  );
};
