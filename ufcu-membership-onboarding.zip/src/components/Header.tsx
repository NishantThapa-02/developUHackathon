import React, { useState } from 'react';
import { NavCategory, STEP_METADATA } from '../types';

interface HeaderProps {
  currentStep: number;
  onSelectStep: (step: number) => void;
  onOpenHelp: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentStep, onSelectStep, onOpenHelp }) => {
  const [showStepDropdown, setShowStepDropdown] = useState(false);

  // Map step to primary category
  const getCurrentCategory = (): NavCategory => {
    if (currentStep <= 3) return 'Discovery';
    if (currentStep === 4) return 'Accounts';
    if (currentStep <= 7) return 'Identity';
    return 'Finish';
  };

  const currentCategory = getCurrentCategory();

  const handleCategoryClick = (cat: NavCategory) => {
    if (cat === 'Discovery') onSelectStep(1);
    else if (cat === 'Accounts') onSelectStep(4);
    else if (cat === 'Identity') onSelectStep(5);
    else if (cat === 'Finish') onSelectStep(8);
  };

  const progressPercentage = Math.round((currentStep / 10) * 100);

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-40 bg-[#f7f9fb]/95 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-slate-200/50">
      <div className="h-20 max-w-5xl mx-auto px-4 md:px-6 flex items-center justify-between gap-4">
        {/* Logo & Title */}
        <div className="flex items-center gap-3 md:gap-4">
          <button 
            onClick={() => onSelectStep(1)} 
            className="flex items-center gap-3 text-left focus:outline-none group cursor-pointer"
            title="Return to Step 1"
          >
            <img 
              alt="UFCU Logo" 
              className="h-8 md:h-9 w-auto object-contain transition-transform group-hover:scale-105" 
              src="https://lh3.googleusercontent.com/aida/AEtjO1WtPSTkb8ucwtZ_jUmoEXjUaCE1Yrv1g_NWC0xENBC4ve3dBIHzXfhh4KLnx9OUxcvrsWkDUMCbF4UgPmd9ZwGxoVAB0jSjs8silpAYbIRdeQI0jinRT0ZHcyP15QcA3hEhCCvweFzwXuLgmMrqzm2u7uiMhMgFDtMdCHsb_BBq87X6H-ksGB3K7U6oML-qqzvUvlIonaj5bmE9PiuT9hHkBbZUMs_kLXzK6zJ03hM37CpjDeEoheyw3Ek"
            />
            <span className="hidden sm:inline-block font-semibold text-lg text-[#23335d] tracking-tight font-['Plus_Jakarta_Sans']">
              Membership Onboarding
            </span>
          </button>
        </div>

        {/* Category Navigation Pills */}
        <nav className="flex items-center gap-1 sm:gap-2" aria-label="Onboarding stages">
          {(['Discovery', 'Identity', 'Accounts', 'Finish'] as NavCategory[]).map((category) => {
            const isActive = currentCategory === category;
            return (
              <button
                key={category}
                type="button"
                onClick={() => handleCategoryClick(category)}
                className={`transition-all duration-200 font-medium text-xs sm:text-sm px-3 sm:px-4 py-1.5 rounded-full cursor-pointer ${
                  isActive 
                    ? 'bg-[#23335d] text-white shadow-sm font-semibold' 
                    : 'text-[#45464f] hover:text-[#0b1d47] hover:bg-slate-200/50'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                {category}
              </button>
            );
          })}
        </nav>

        {/* Right Action Tray: Quick Screen Switcher, Help & Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Step Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowStepDropdown(!showStepDropdown)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-white border border-slate-200 text-[#0b1d47] shadow-xs hover:border-[#fc712a] transition-colors cursor-pointer"
              title="Jump to any screen"
            >
              <span className="w-2 h-2 rounded-full bg-[#fc712a] animate-pulse"></span>
              <span>Screen {currentStep}/10</span>
              <span className="material-symbols-outlined text-[16px] text-slate-400">expand_more</span>
            </button>

            {showStepDropdown && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowStepDropdown(false)}
                />
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-fadeIn text-left max-h-96 overflow-y-auto">
                  <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Quick Jump to Screen
                  </div>
                  {STEP_METADATA.map((s) => (
                    <button
                      key={s.number}
                      type="button"
                      onClick={() => {
                        onSelectStep(s.number);
                        setShowStepDropdown(false);
                      }}
                      className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer ${
                        currentStep === s.number ? 'bg-orange-50/70 font-semibold text-[#fc712a]' : 'text-[#191c1e]'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                          currentStep === s.number ? 'bg-[#fc712a] text-white' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {s.number}
                        </span>
                        <span className="truncate">{s.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0 ml-1">{s.category}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Help Button */}
          <button 
            onClick={onOpenHelp}
            className="hidden sm:inline-flex items-center gap-1 text-xs sm:text-sm font-medium text-[#45464f] hover:text-[#23335d] transition-colors py-1.5 px-2.5 rounded-lg hover:bg-slate-200/50 cursor-pointer" 
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">help_outline</span>
            <span>Help</span>
          </button>

          {/* Profile Avatar */}
          <div 
            className="w-8 h-8 rounded-full bg-[#0b1d47] flex items-center justify-center text-white shadow-xs"
            title="Member Profile"
          >
            <span className="material-symbols-outlined text-white text-[18px]">person</span>
          </div>
        </div>
      </div>

      {/* Segmented Top Progress Bar */}
      <div className="w-full bg-[#e6e8ea] h-1">
        <div 
          className="bg-[#fc712a] h-1 rounded-full transition-all duration-300"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
    </header>
  );
};
